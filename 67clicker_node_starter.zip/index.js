const express = require("express");
const session = require("express-session");

const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: "change_this_secret",
  resave: false,
  saveUninitialized: true
}));

app.get("/", (req, res) => {
  res.send("<h1>67 Clicker Sign Up</h1>");
});

app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});
